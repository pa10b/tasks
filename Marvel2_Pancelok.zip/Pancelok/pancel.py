class Pancel:
    __nev = ""
    __tipus = ""
    __felvetel = 0
    __sebzes = 0

    def __init__(self):


    def nev(self):
        return self.__nev

    def tipus(self):
        return "Mark-" + self.__tipus

    def felvetel(self):
        return self.__felvetel

    def sebzes(self):
        return self.__sebzes

    def harci_ertek(self):
