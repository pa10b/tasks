class Technology:
    _name = ""
    _category = ""
    _description = ""
    _rating = 0.0

    def __init__(self):
        

    @property
    def name(self):
        return self._name

    @property
    def category(self):
        return self._category

    @property
    def description(self):
        return self._description

    @property
    def rating(self):
        return self._rating